package com.booking.MovieApp.models;

import com.booking.MovieApp.controller.AuthStatus;

public record AuthResponseDto(String token, AuthStatus authStatus) {

}
