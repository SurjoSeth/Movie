package com.booking.MovieApp.models;


import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "movieEntity")
public class movieEntity {

    @Id
    private ObjectId _id;
    @NotNull
    private String movieName;
    @NotNull
    private String theatreName;
    @NotNull
    private int totalAllottedTickets;
    @NotNull
    private MovieStatus status;
    @NotNull
    private List<String> allSeat;

    private List<String> availableSeats;
}
