package com.booking.MovieApp.models;

//import jakarta.persistence.;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "userEntity")
public class userEntity {

    private ObjectId _id;
    @NotNull
    private String firstName;
    @NotNull
    private String lastName;

    @Id
    @NotNull
    private String email;
    @NotNull
    private String password;
    @NotNull
    private String contactNumber;

//    @NotNull
    private Roles role;

//    @NotNull
    private List<GrantedAuthority> authorities;

    private List<ticketEntity> tickets;

}
