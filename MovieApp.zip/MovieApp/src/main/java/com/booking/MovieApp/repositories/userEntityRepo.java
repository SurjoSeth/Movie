package com.booking.MovieApp.repositories;

import com.booking.MovieApp.models.ticketEntity;
import com.booking.MovieApp.models.userEntity;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface userEntityRepo extends MongoRepository<userEntity, String> {
    userEntity findByEmail(String username);

    boolean existsByEmail(String email);

    userEntity findByTickets(ticketEntity ticket);
}
