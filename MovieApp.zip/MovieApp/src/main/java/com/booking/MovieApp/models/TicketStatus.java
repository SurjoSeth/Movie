package com.booking.MovieApp.models;

public enum TicketStatus {

    BOOKED,

    CHECKED,

    EXPIRED
}
