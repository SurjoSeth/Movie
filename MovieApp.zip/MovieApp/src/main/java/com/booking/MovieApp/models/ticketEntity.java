package com.booking.MovieApp.models;


import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "ticketEntity")
public class ticketEntity {

//    @Id
    private ObjectId _id;
    @NotNull
    private String movieName;
    @NotNull
    private String theatreName;
    @NotNull
    private int noOfTicket;
    @NotNull
    private List<String> seatNo;
    @NotNull
    private TicketStatus status;
}
