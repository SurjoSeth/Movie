package com.booking.MovieApp.service.auth;

import com.booking.MovieApp.models.userEntity;
import com.booking.MovieApp.repositories.userEntityRepo;

import com.booking.MovieApp.util.JwtUtils;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

import static com.booking.MovieApp.models.Roles.ADMIN;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;
    private final userEntityRepo repo;


    @Override
    public String login(String username, String password) {
        var authToken=new UsernamePasswordAuthenticationToken(username,password);
        var authenticate=authenticationManager.authenticate(authToken);
        return JwtUtils.generateToken(((UserDetails)(authenticate.getPrincipal())).getUsername());
    }

    @Override
    public String signUp(userEntity user) {
        if(repo.existsByEmail(user.getEmail())){
            throw new RuntimeException("User already exists");
        }
        var encodedPassword=passwordEncoder.encode(user.getPassword());

        var authorities=new ArrayList<GrantedAuthority>();
        if(user.getRole()==ADMIN)
            authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
        else
            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));

        user.setAuthorities(authorities);
        user.setPassword(encodedPassword);
        repo.save(user);
        return JwtUtils.generateToken(user.getEmail());

    }
}
