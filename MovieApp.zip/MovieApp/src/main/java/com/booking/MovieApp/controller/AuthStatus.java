package com.booking.MovieApp.controller;

public enum AuthStatus {
    USER_CREATED_SUCCESSFULLY, USER_NOT_CREATED, LOGIN_SUCCESS, LOGIN_FAILED
}
