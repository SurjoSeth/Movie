package com.booking.MovieApp.service;

import com.booking.MovieApp.exceptions.NotFoundException;
import com.booking.MovieApp.models.*;
import org.springframework.stereotype.Service;

@Service
public interface ticketService {

    ticketEntity bookTicket(String email,ticketEntity ticket) throws NotFoundException;

    ticketEntity updateStatus(ticketEntity ticket, TicketStatus status, String email);

}
