package com.booking.MovieApp.service;

import com.booking.MovieApp.models.movieEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface movieService {

    movieEntity addMovie(movieEntity movie);

    List<movieEntity> viewAll();

    List<movieEntity> getByMovie(String movie);

    movieEntity deleteMovie(movieEntity movie);


}
