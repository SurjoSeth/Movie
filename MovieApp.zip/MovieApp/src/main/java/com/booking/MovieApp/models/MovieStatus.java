package com.booking.MovieApp.models;

public enum MovieStatus {

    BOOK_ASAP,

    SOLD_OUT
}
