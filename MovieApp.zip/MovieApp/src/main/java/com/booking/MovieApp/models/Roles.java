package com.booking.MovieApp.models;

public enum Roles {

    ADMIN,

    USER
}
