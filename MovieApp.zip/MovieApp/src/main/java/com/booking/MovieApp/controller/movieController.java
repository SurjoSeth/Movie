package com.booking.MovieApp.controller;

import com.booking.MovieApp.models.movieEntity;
import com.booking.MovieApp.service.movieService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/api/v1.0/moviebooking")
@RequiredArgsConstructor
public class movieController {

    @Autowired
    private final movieService service;

    @PostMapping("/admin/add")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public movieEntity addMovie(@RequestBody movieEntity movie){
      return service.addMovie(movie);
    }

    @GetMapping("/all")
    public List<movieEntity> viewAll(){
        return service.viewAll();
    }

    @GetMapping("/movies/search/{moviename}")
    public List<movieEntity> getByMovieName(@PathVariable String moviename){
        return service.getByMovie(moviename);
    }

    @DeleteMapping("/admin/delete")
    @PreAuthorize("hasAuthority('ROLE_ADMIN)")
    public movieEntity deleteMovie(@RequestBody movieEntity movie){
        return  service.deleteMovie(movie);
    }

}
