package com.booking.MovieApp.repositories;

import com.booking.MovieApp.models.movieEntity;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface movieRepository extends MongoRepository<movieEntity, ObjectId> {

    List<movieEntity> findByMovieName(String movie);

    movieEntity findByMovieNameAndTheatreName(String movieName, String theatreName);
}
