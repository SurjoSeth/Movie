package com.booking.MovieApp.service;

import com.booking.MovieApp.models.movieEntity;
import com.booking.MovieApp.repositories.movieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.context.annotation.Bean;

import java.util.List;
@Service
public class movieServiceImpl implements movieService{

//    @Autowired
    private final movieRepository repo;

    public movieServiceImpl(movieRepository repo) {
        this.repo = repo;
    }

    @Override
    public movieEntity addMovie(movieEntity movie) {
        repo.save(movie);
        return movie;
    }

    @Override
    public List<movieEntity> viewAll() {
        return repo.findAll();
    }

    @Override
    public List<movieEntity> getByMovie(String movie) {
        return repo.findByMovieName(movie);
    }

    @Override
    public movieEntity deleteMovie(movieEntity movie) {
        repo.deleteById(repo.findByMovieNameAndTheatreName(movie.getMovieName(),movie.getTheatreName()).get_id());
        return movie;
    }
}
