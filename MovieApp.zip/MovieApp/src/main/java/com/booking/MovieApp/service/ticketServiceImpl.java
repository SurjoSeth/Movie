package com.booking.MovieApp.service;

import com.booking.MovieApp.exceptions.NotFoundException;
import com.booking.MovieApp.models.*;
import com.booking.MovieApp.repositories.movieRepository;
import com.booking.MovieApp.repositories.ticketRepository;
import com.booking.MovieApp.repositories.userEntityRepo;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static com.booking.MovieApp.models.MovieStatus.SOLD_OUT;

@Service
public class ticketServiceImpl implements ticketService {

    private final ticketRepository repo;

    private final movieRepository mRepo;

    private final userEntityRepo uRepo;

    public ticketServiceImpl(ticketRepository repo, movieRepository mRepo, userEntityRepo uRepo) {
        this.repo = repo;
        this.mRepo = mRepo;
        this.uRepo = uRepo;
    }

    @Override
    public ticketEntity bookTicket(String email, ticketEntity ticket) throws NotFoundException {
        userEntity user=uRepo.findByEmail(email);
        List<String> newAvail;
        movieEntity me=mRepo.findByMovieNameAndTheatreName(ticket.getMovieName(),ticket.getTheatreName());
        newAvail=me.getAvailableSeats();
        for(String t:ticket.getSeatNo()){
            if(newAvail.contains(t))
            {newAvail.remove(t);}
            else
                throw new NotFoundException("Seats already booked");
        }
        System.out.println(newAvail);
        repo.save(ticket);
        List<ticketEntity> lt=user.getTickets();
        lt.add(ticket);
        user.set_id(user.get_id());
        user.setTickets(lt);
        uRepo.save(user);
        me.setAvailableSeats(newAvail);


        if(me.getAvailableSeats().size()==0)
            me.setStatus(SOLD_OUT);

        mRepo.save(me);
        return ticket;
    }

    @Override
    public ticketEntity updateStatus(ticketEntity ticket,TicketStatus status, String email) {
        userEntity user=uRepo.findByEmail(email);
        List<ticketEntity> lt=user.getTickets();
        System.out.println(ticket);
        ticket.set_id(ticket.get_id());
        System.out.println(lt);
        System.out.println(ticket);
        lt.remove(ticket);
        ticket.setStatus(status);
        lt.add(ticket);

        user.setTickets(lt);
        uRepo.save(user);
        repo.save(ticket);
        return ticket;
    }
}
