package com.booking.MovieApp.service.auth;

import com.booking.MovieApp.models.userEntity;

public interface AuthService {

    String login(String username, String password);

    String signUp(userEntity user);
}
