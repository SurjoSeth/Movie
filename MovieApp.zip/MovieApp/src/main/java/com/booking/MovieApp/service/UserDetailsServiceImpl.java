package com.booking.MovieApp.service;

import com.booking.MovieApp.repositories.userEntityRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {

    private final userEntityRepo repo;
    @Override
    public UserDetails loadUserByUsername(String username)
    {
        var user= repo.findByEmail(username);
//                .orElseThrow(()->new UsernameNotFoundException("Not Found"));
        var authorities=new ArrayList<GrantedAuthority>();
        authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
        return new User(user.getEmail(),user.getPassword(),user.getAuthorities());
    }
}
