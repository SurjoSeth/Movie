package com.booking.MovieApp.repositories;

import com.booking.MovieApp.models.ticketEntity;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ticketRepository extends MongoRepository<ticketEntity, ObjectId> {
}
