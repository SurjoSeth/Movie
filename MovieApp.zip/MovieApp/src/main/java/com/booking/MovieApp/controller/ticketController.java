package com.booking.MovieApp.controller;


import com.booking.MovieApp.models.TicketStatus;
import com.booking.MovieApp.models.ticketEntity;
import com.booking.MovieApp.service.ticketService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@RequestMapping("/api/v1.0/moviebooking")
@RequiredArgsConstructor
public class ticketController {

    @Autowired
    private final ticketService service;

    @PostMapping("/user/addTicket/{email}")
    public ticketEntity bookTicket(@PathVariable String email,@RequestBody ticketEntity ticket) throws Exception {
        return service.bookTicket(email, ticket);
    }

    @PutMapping("/admin/updateTicket/{email}/{status}")
//    @PreAuthorize("hasRole(ADMIN)")
    public ticketEntity updateTicketStatus(@RequestBody ticketEntity ticket, @PathVariable TicketStatus status, @PathVariable String email){
        return service.updateStatus(ticket,status, email);
    }

}
